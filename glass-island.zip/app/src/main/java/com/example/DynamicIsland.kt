package com.example

import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun DynamicIsland() {
    val currentMode by IslandState.currentMode.collectAsState()

    val context = LocalContext.current
    val pm = context.packageManager
    
    // Pre-load icons to achieve 60fps butter-smooth animations without binder call lag
    val selectedApps = remember(currentMode == IslandMode.EXPANDED) {
        AppShortcutManager.getSelectedPackages(context).take(5)
    }
    
    val shortcutIcons = remember(selectedApps) {
        selectedApps.mapNotNull { pkg ->
            try {
                pkg to pm.getApplicationIcon(pkg).toBitmap().asImageBitmap()
            } catch(e: Exception) { null }
        }
    }

    val targetWidth = when (currentMode) {
        IslandMode.EXPANDED -> 340.dp
        IslandMode.NOTIFICATION -> 340.dp
        IslandMode.IDLE -> 120.dp
        IslandMode.HIDDEN -> 0.dp
        else -> 120.dp
    }
    
    val targetHeight = when (currentMode) {
        IslandMode.EXPANDED -> 68.dp
        IslandMode.NOTIFICATION -> 80.dp
        IslandMode.IDLE -> 36.dp
        IslandMode.HIDDEN -> 0.dp
        else -> 36.dp
    }

    val springSpecWidth = spring<androidx.compose.ui.unit.Dp>(
        dampingRatio = 0.65f, // Snappy bounce
        stiffness = Spring.StiffnessMediumLow
    )
    val springSpecHeight = spring<androidx.compose.ui.unit.Dp>(
        dampingRatio = 0.65f,
        stiffness = Spring.StiffnessMediumLow
    )

    val animatedWidth by animateDpAsState(targetValue = targetWidth, animationSpec = springSpecWidth, label = "width")
    val animatedHeight by animateDpAsState(targetValue = targetHeight, animationSpec = springSpecHeight, label = "height")
    
    val islandShape = RoundedCornerShape(percent = 50)

    Box(
        modifier = Modifier
            .fillMaxWidth(),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(
            modifier = Modifier
                .padding(top = 8.dp) // Float slightly below top edge for fully rounded look
                .width(animatedWidth)
                .height(animatedHeight)
                .clip(islandShape)
                .background(if (animatedWidth > 1.dp) Color.Black else Color.Transparent)
                .border(
                    width = if (animatedWidth > 1.dp) 0.5.dp else 0.dp, 
                    color = if (animatedWidth > 1.dp) Color(0x1AFFFFFF) else Color.Transparent, 
                    shape = islandShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (currentMode == IslandMode.EXPANDED) {
                        IslandState.currentMode.value = IslandMode.IDLE
                    } else {
                        IslandState.currentMode.value = IslandMode.EXPANDED
                    }
                }
                .padding(horizontal = 14.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = currentMode, animationSpec = tween(150), label = "contentXFade") { mode ->
                when (mode) {
                    IslandMode.EXPANDED -> {
                        ExpandedContent(
                            shortcutIcons = shortcutIcons,
                            onLaunchApp = { pkg ->
                                val intent = pm.getLaunchIntentForPackage(pkg)
                                if (intent != null) {
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                    context.startActivity(intent)
                                    IslandState.currentMode.value = IslandMode.IDLE
                                }
                            }
                        )
                    }
                    IslandMode.NOTIFICATION -> {
                        NotificationContent()
                    }
                    IslandMode.IDLE -> {
                        IdleContent()
                    }
                    IslandMode.HIDDEN -> {
                        // Render nothing
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
fun ExpandedContent(
    shortcutIcons: List<Pair<String, ImageBitmap>>,
    onLaunchApp: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = if (shortcutIcons.isEmpty()) Arrangement.Center else Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for ((pkg, icon) in shortcutIcons) {
            Image(
                bitmap = icon,
                contentDescription = null,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable { onLaunchApp(pkg) }
            )
        }
        if (shortcutIcons.isEmpty()) {
            Text("Add shortcuts in settings", color = Color.Gray, fontSize = 14.sp)
        }
    }
}

@Composable
fun NotificationContent() {
    val title by IslandState.notificationTitle.collectAsState()
    val text by IslandState.notificationText.collectAsState()
    
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = androidx.compose.material.icons.Icons.Default.Notifications,
                contentDescription = null,
                tint = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title.ifEmpty { "Notification" },
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = text,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun IdleContent() {
    Row(
        modifier = Modifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(CircleShape)
                .background(Color.White.copy(0.05f))
        )
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(CircleShape)
                .background(Color.Green)
        )
    }
}

