package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*

class DynamicIslandService : Service() {

    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private val overlayLifecycleOwner = ComposeOverlayLifecycleOwner()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Default Android launchers to filter
    private val launcherPackages = listOf(
        "com.google.android.apps.nexuslauncher", 
        "com.android.launcher",
        "com.android.launcher2",
        "com.android.launcher3",
        "com.sec.android.app.launcher",
        "com.sec.android.app.easylauncher",
        "com.miui.home", 
        "com.mi.android.globallauncher",
        "com.huawei.android.launcher", 
        "com.oppo.launcher", 
        "com.bbk.launcher2", 
        "com.vivo.launcher", 
        "net.oneplus.launcher",
        "com.nothing.launcher",
        "com.motorola.launcher3",
        "com.transsion.XOSLauncher",
        "com.transsion.hilauncher",
        "com.itel.launcher",
        "com.microsoft.launcher",
        "com.teslacoilsw.launcher" // Nova Launcher
    )

    
    private var cachedDefaultLauncher: String? = null
    private var lastLauncherCheckTime: Long = 0

    private fun getDefaultLauncher(): String? {
        val now = System.currentTimeMillis()
        if (now - lastLauncherCheckTime > 10000) {
            val intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_HOME)
            val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            cachedDefaultLauncher = resolveInfo?.activityInfo?.packageName
            lastLauncherCheckTime = now
        }
        return cachedDefaultLauncher
    }

    private fun isLauncher(packageName: String): Boolean {
        if (launcherPackages.contains(packageName)) return true
        return packageName == getDefaultLauncher()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        
        createNotificationChannel()
        val notification = NotificationCompat.Builder(this, "DynamicIslandChannel")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        startForeground(1, notification)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        
        overlayLifecycleOwner.onCreate()

        composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(overlayLifecycleOwner)
            setViewTreeSavedStateRegistryOwner(overlayLifecycleOwner)
            setViewTreeViewModelStoreOwner(overlayLifecycleOwner)
            setContent {
                MyApplicationTheme {
                    DynamicIsland()
                }
            }
            setOnTouchListener { _, event ->
                if (event.action == android.view.MotionEvent.ACTION_OUTSIDE) {
                    if (IslandState.currentMode.value == IslandMode.EXPANDED) {
                        IslandState.currentMode.value = IslandMode.IDLE
                    }
                    true
                } else {
                    false
                }
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            screenOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = 0 // align exactly with top edge for teardrop notch

        windowManager.addView(composeView, params)
        startAppMonitoring()
    }

    private val launchablePackages = mutableMapOf<String, Boolean>()
    
    private fun isLaunchable(pkg: String): Boolean {
        return launchablePackages.getOrPut(pkg) {
            packageManager.getLaunchIntentForPackage(pkg) != null
        }
    }

    private fun startAppMonitoring() {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        scope.launch {
            var lastKnownApp: String? = null
            var lastEventTime: Long = 0
            while (isActive) {
                val endTime = System.currentTimeMillis()
                val beginTime = endTime - 2000
                
                var currentApp: String? = null
                val usageEvents = usageStatsManager.queryEvents(beginTime, endTime)
                val event = UsageEvents.Event()
                while (usageEvents.hasNextEvent()) {
                    usageEvents.getNextEvent(event)
                    if (event.timeStamp > lastEventTime) {
                        lastEventTime = event.timeStamp
                    }
                    if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                        val pkg = event.packageName
                        // Only consider packages that are SystemUI, a Launcher, our app, or a launchable user app
                        if (pkg == "com.android.systemui" || isLauncher(pkg) || pkg == packageName || isLaunchable(pkg)) {
                            currentApp = pkg
                        }
                    }
                }
                
                if (currentApp != null) {
                    lastKnownApp = currentApp
                }
                
                if (lastKnownApp != null) {
                    val isSystemUI = lastKnownApp == "com.android.systemui"
                    val launcherMatch = isLauncher(lastKnownApp!!)
                    val isMyApp = lastKnownApp == packageName
                    
                    if (launcherMatch || isMyApp || isSystemUI) {
                        if (IslandState.currentMode.value == IslandMode.HIDDEN) {
                            IslandState.currentMode.value = IslandMode.IDLE
                        }
                    } else {
                        IslandState.currentMode.value = IslandMode.HIDDEN
                    }
                }
                
                delay(500)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        composeView?.let { windowManager.removeView(it) }
        overlayLifecycleOwner.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "DynamicIslandChannel",
                "Dynamic Island Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}

class ComposeOverlayLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    fun onCreate() {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    fun onDestroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}
