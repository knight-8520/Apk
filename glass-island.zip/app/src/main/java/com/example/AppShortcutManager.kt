package com.example

import android.content.Context
import android.content.SharedPreferences

object AppShortcutManager {
    private const val PREFS_NAME = "DynamicIslandPrefs"
    private const val KEY_SELECTED_APPS = "SelectedApps"

    fun getSelectedPackages(context: Context): List<String> {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_SELECTED_APPS, emptySet())?.toList() ?: emptyList()
    }

    fun saveSelectedPackages(context: Context, packages: List<String>) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putStringSet(KEY_SELECTED_APPS, packages.toSet()).apply()
    }

    fun addPackage(context: Context, packageName: String) {
        val current = getSelectedPackages(context).toMutableList()
        if (!current.contains(packageName)) {
            current.add(packageName)
            saveSelectedPackages(context, current)
        }
    }

    fun removePackage(context: Context, packageName: String) {
        val current = getSelectedPackages(context).toMutableList()
        current.remove(packageName)
        saveSelectedPackages(context, current)
    }
}
