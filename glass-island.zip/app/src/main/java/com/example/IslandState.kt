package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class IslandMode {
    IDLE, EXPANDED, HIDDEN, NOTIFICATION
}

object IslandState {
    val currentMode = MutableStateFlow(IslandMode.IDLE)
    val shouldIntercept = MutableStateFlow(true)
    
    val notificationTitle = MutableStateFlow("")
    val notificationText = MutableStateFlow("")
    
    private val scope = CoroutineScope(Dispatchers.Main)
    
    fun showNotification(title: String, text: String) {
        notificationTitle.value = title
        notificationText.value = text
        currentMode.value = IslandMode.NOTIFICATION
        
        scope.launch {
            delay(5000)
            if (currentMode.value == IslandMode.NOTIFICATION) {
                currentMode.value = IslandMode.IDLE
            }
        }
    }
}
