package com.example

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class IslandNotificationService : NotificationListenerService() {
    
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        sbn?.let {
            val title = it.notification.extras.getString(Notification.EXTRA_TITLE)
            val text = it.notification.extras.getString(Notification.EXTRA_TEXT)
            Log.d("IslandNotification", "Posted: $title - $text")
            
            // Forward to our island UI
            IslandState.showNotification(title ?: "Notification", text ?: "")
            
            // Optionally try to cancel it (per user request)
            if (IslandState.shouldIntercept.value) {
                cancelNotification(it.key)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }
}
