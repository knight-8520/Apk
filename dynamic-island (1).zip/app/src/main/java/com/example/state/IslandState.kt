package com.example.state

import android.app.PendingIntent
import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class IslandMode {
    HIDDEN, IDLE, NOTIFICATION, EXPANDED, TOAST
}

data class IslandData(
    val mode: IslandMode = IslandMode.HIDDEN,
    val title: String = "",
    val text: String = "",
    val icon: Bitmap? = null,
    val appName: String = "",
    val pendingIntent: PendingIntent? = null
)

object IslandState {
    private val _state = MutableStateFlow(IslandData(mode = IslandMode.IDLE))
    val state: StateFlow<IslandData> = _state.asStateFlow()

    fun updateState(newData: IslandData) {
        _state.value = newData
    }

    fun hide() {
        _state.value = _state.value.copy(mode = IslandMode.IDLE)
    }
}
