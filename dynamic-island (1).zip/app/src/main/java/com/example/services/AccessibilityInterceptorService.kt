package com.example.services

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.example.state.IslandData
import com.example.state.IslandMode
import com.example.state.IslandState

class AccessibilityInterceptorService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val className = event.className?.toString() ?: ""
            if (className.contains("Toast")) {
                val text = event.text.joinToString(" ")
                if (text.isNotBlank()) {
                    IslandState.updateState(
                        IslandData(
                            mode = IslandMode.TOAST,
                            text = text
                        )
                    )

                    handler.removeCallbacksAndMessages(null)
                    handler.postDelayed({
                        IslandState.updateState(IslandData(mode = IslandMode.IDLE))
                    }, 3000)
                }
            }
        }
    }

    override fun onInterrupt() {
        // Required
    }
}
