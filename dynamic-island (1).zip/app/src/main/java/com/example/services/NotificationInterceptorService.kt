package com.example.services

import android.app.Notification
import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.state.IslandData
import com.example.state.IslandMode
import com.example.state.IslandState

class NotificationInterceptorService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Ignore ongoing notifications or our own service
        if (sbn.isOngoing || sbn.packageName == packageName) return

        val notification = sbn.notification
        val title = notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        var text = notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val bigText = notification.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        if (!bigText.isNullOrBlank()) {
            text = bigText
        }
        val appName = packageManager.getApplicationLabel(
            packageManager.getApplicationInfo(sbn.packageName, 0)
        ).toString()

        val iconBitmap = getIconBitmap(notification.getLargeIcon() ?: notification.smallIcon)

        // Cancel the system drop down by canceling the notification (or effectively silencing it)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION.SDK_INT) {
                cancelNotification(sbn.key)
            }
        } catch (e: Exception) {
            Log.e("NotificationInterceptor", "Failed to cancel notification", e)
        }

        // Show on island
        IslandState.updateState(
            IslandData(
                mode = IslandMode.NOTIFICATION,
                title = title,
                text = text,
                icon = iconBitmap,
                appName = appName,
                pendingIntent = notification.contentIntent
            )
        )

        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            IslandState.updateState(IslandData(mode = IslandMode.IDLE))
        }, 5000)
    }

    private fun getIconBitmap(icon: Icon?): Bitmap? {
        if (icon == null) return null
        val drawable: Drawable = icon.loadDrawable(this) ?: return null
        return if (drawable is BitmapDrawable) {
            drawable.bitmap
        } else {
            // Need a proper conversion, returning null for simplicity here
            null
        }
    }
}
