package com.example.ui.island

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.state.IslandMode
import com.example.state.IslandState

@Composable
fun DynamicIslandOverlay() {
    val state by IslandState.state.collectAsState()

    val targetWidth = when (state.mode) {
        IslandMode.HIDDEN -> 0.dp
        IslandMode.IDLE -> 120.dp
        IslandMode.NOTIFICATION -> 340.dp
        IslandMode.EXPANDED -> 340.dp
        IslandMode.TOAST -> 280.dp
    }

    val targetHeight = when (state.mode) {
        IslandMode.HIDDEN -> 0.dp
        IslandMode.IDLE -> 36.dp
        IslandMode.NOTIFICATION -> 80.dp
        IslandMode.EXPANDED -> 68.dp
        IslandMode.TOAST -> 48.dp
    }

    val width by animateDpAsState(
        targetValue = targetWidth,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "width"
    )
    val height by animateDpAsState(
        targetValue = targetHeight,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "height"
    )

    if (state.mode == IslandMode.HIDDEN) {
        return
    }

    Box(
        modifier = Modifier
            .width(width)
            .height(height)
            .clip(RoundedCornerShape(percent = 50))
            .background(Color.Black)
            .clickable {
                state.pendingIntent?.send()
            },
        contentAlignment = Alignment.Center
    ) {
        if (state.mode == IslandMode.NOTIFICATION && width > 200.dp) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state.icon != null) {
                    Image(
                        bitmap = state.icon!!.asImageBitmap(),
                        contentDescription = "App Icon",
                        modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Box(modifier = Modifier.size(40.dp).background(Color.Gray, RoundedCornerShape(8.dp)))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = state.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = state.text,
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        } else if (state.mode == IslandMode.TOAST && width > 150.dp) {
            Text(
                text = state.text,
                color = Color.White,
                fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 16.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        } else if (state.mode == IslandMode.IDLE && width > 50.dp) {
            // Idle camera cutout mask
        }
    }
}
