package com.example

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.example.ui.theme.MyApplicationTheme
import com.example.services.IslandOverlayService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager

import android.app.NotificationManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    OnboardingScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun OnboardingScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var canDrawOverlays by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var hasNotificationAccess by remember { mutableStateOf(checkNotificationAccess(context)) }
    var hasAccessibilityAccess by remember { mutableStateOf(checkAccessibilityAccess(context)) }
    var hasBatteryAccess by remember { mutableStateOf(checkBatteryAccess(context)) }
    var hasDndAccess by remember { mutableStateOf(checkDndAccess(context)) }

    LaunchedEffect(Unit) {
        while (true) {
            canDrawOverlays = Settings.canDrawOverlays(context)
            hasNotificationAccess = checkNotificationAccess(context)
            hasAccessibilityAccess = checkAccessibilityAccess(context)
            hasBatteryAccess = checkBatteryAccess(context)
            hasDndAccess = checkDndAccess(context)
            kotlinx.coroutines.delay(1000)
        }
    }
    
    val allGranted = canDrawOverlays && hasNotificationAccess && hasAccessibilityAccess && hasBatteryAccess && hasDndAccess

    LaunchedEffect(allGranted) {
        if (allGranted) {
            val intent = Intent(context, IslandOverlayService::class.java)
            context.startForegroundService(intent)
        }
    }

    val bgTheme = Color(0xFFF3EDF7)
    val titleText = Color(0xFF1D1B20)
    val subText = Color(0xFF49454F)

    val cardBg = Color(0xFFFEF7FF)
    val cardBorder = Color(0xFFCAC4D0)
    val cardHeaderBg = Color(0xFFF7F2FA)

    val statusCardBg = Color(0xFFE8DEF8)
    val statusIconBg = Color(0xFF6750A4)
    val statusText = Color(0xFF21005D)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(bgTheme)
            .padding(horizontal = 16.dp, vertical = 24.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp)) {
            Text("Control Center", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = titleText)
            Text("Dynamic Island & Interceptor Status", fontSize = 14.sp, color = subText)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // STATUS CARD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(statusCardBg, RoundedCornerShape(24.dp))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(40.dp).background(statusIconBg, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("⚡", color = Color.White)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("INTERCEPTOR SERVICE", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = statusText)
                    Text(if (allGranted) "Active & Monitoring" else "Setup Required", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = statusText)
                }
            }
            Box(
                modifier = Modifier
                    .size(width = 48.dp, height = 32.dp)
                    .background(statusIconBg, RoundedCornerShape(50))
                    .padding(4.dp),
                contentAlignment = if (allGranted) Alignment.CenterEnd else Alignment.CenterStart
            ) {
                Box(modifier = Modifier.size(24.dp).background(Color.White, RoundedCornerShape(50)))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        
        // PERMISSIONS MATRIX
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, cardBorder, RoundedCornerShape(24.dp))
                .background(cardBg, RoundedCornerShape(24.dp))
        ) {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(cardHeaderBg, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
               Text("CORE PERMISSIONS", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = subText)
            }
            HorizontalDivider(color = cardBorder, thickness = 1.dp)

            PermissionRow(
                title = "System Overlay",
                description = "Draw floating island UI",
                isGranted = canDrawOverlays,
                isLast = false,
                onClick = {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                    context.startActivity(intent)
                }
            )
            
            PermissionRow(
                title = "Notification Access",
                description = "Intercept & suppress system HUD",
                isGranted = hasNotificationAccess,
                isLast = false,
                onClick = {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    context.startActivity(intent)
                }
            )
            
            PermissionRow(
                title = "Accessibility Service",
                description = "Required for Toast redirection",
                isGranted = hasAccessibilityAccess,
                isLast = false,
                onClick = {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    context.startActivity(intent)
                }
            )

            PermissionRow(
                title = "Ignore Battery Optimizations",
                description = "Prevents OS from killing service",
                isGranted = hasBatteryAccess,
                isLast = false,
                onClick = {
                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    context.startActivity(intent)
                }
            )

            PermissionRow(
                title = "Do Not Disturb Access",
                description = "Prevents native HUD (popups)",
                isGranted = hasDndAccess,
                isLast = true,
                onClick = {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    context.startActivity(intent)
                }
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Button(
            onClick = {
                val intent = Intent(context, IslandOverlayService::class.java)
                context.startForegroundService(intent)
            },
            enabled = allGranted,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6750A4),
                disabledContainerColor = Color(0xFFCAC4D0)
            )
        ) {
            Text("Launch Island")
        }
    }
}

@Composable
fun PermissionRow(title: String, description: String, isGranted: Boolean, isLast: Boolean, onClick: () -> Unit) {
    val iconGreenBg = Color(0xFFDCFCE7)
    val iconGreenText = Color(0xFF15803D)
    
    val iconAmberBg = Color(0xFFFEF3C7)
    val iconAmberText = Color(0xFFB45309)

    val rowBorder = Color(0xFFF0EBEF)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .background(if (isGranted) iconGreenBg else iconAmberBg, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (isGranted) "✓" else "!", color = if (isGranted) iconGreenText else iconAmberText, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1C1B1F))
            Text(description, fontSize = 11.sp, color = Color(0xFF49454F))
        }
        if (!isGranted) {
           Text(
               "GRANT", 
               fontSize = 10.sp, 
               fontWeight = FontWeight.Bold, 
               color = Color(0xFF6750A4), 
               modifier = Modifier
                   .border(1.dp, Color(0xFF6750A4), RoundedCornerShape(50))
                   .padding(horizontal = 12.dp, vertical = 6.dp)
           )
        }
    }
    if (!isLast) {
        HorizontalDivider(color = rowBorder, thickness = 1.dp)
    }
}

fun checkNotificationAccess(context: Context): Boolean {
    val enabledListeners = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
    return enabledListeners?.contains(context.packageName) == true
}

fun checkAccessibilityAccess(context: Context): Boolean {
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
    return enabledServices.any { it.resolveInfo.serviceInfo.packageName == context.packageName }
}

fun checkBatteryAccess(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

fun checkDndAccess(context: Context): Boolean {
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    return nm.isNotificationPolicyAccessGranted
}
